package com.iexceed.appzillonbanking.core.startup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailBankingCore {

	public static void main(String[] args) {
		SpringApplication.run(RetailBankingCore.class, args);
	}

}
